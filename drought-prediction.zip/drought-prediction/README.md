# 🌾 Drought Prediction System
### Deep Learning-based Drought Forecasting using Satellite Remote Sensing

A major project for predicting drought conditions using NDVI, rainfall, and climate indices,
powered by a CNN-LSTM deep learning model and visualized through an interactive Streamlit dashboard.

---

## 📁 Project Structure

```
drought-prediction/
│
├── data/
│   ├── raw/                  ← Raw GeoTIFF / NetCDF files
│   └── processed/            ← Preprocessed numpy arrays
│
├── model/
│   ├── train.py              ← Model training script
│   ├── evaluate.py           ← Evaluation & metrics
│   └── saved_model/          ← Saved .h5 model (after training)
│
├── app/
│   └── dashboard.py          ← Streamlit dashboard
│
├── utils/
│   ├── preprocess.py         ← Data preprocessing pipeline
│   ├── gee_fetch.py          ← Google Earth Engine data fetcher
│   ├── indices.py            ← Drought index calculations (SPI, VCI, TCI)
│   └── visualize.py          ← Plotting utilities
│
├── notebooks/
│   └── exploration.ipynb     ← EDA notebook
│
├── requirements.txt
├── README.md
└── config.py                 ← Global config
```

---

## 🚀 Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Authenticate Google Earth Engine
```bash
earthengine authenticate
```

### 3. Fetch Data
```bash
python utils/gee_fetch.py
```

### 4. Preprocess Data
```bash
python utils/preprocess.py
```

### 5. Train the Model
```bash
python model/train.py
```

### 6. Launch Dashboard
```bash
streamlit run app/dashboard.py
```

---

## 🧠 Model Architecture

- **Input**: Sequences of [NDVI, Rainfall, LST, SPI] over a 12-month window
- **Architecture**: CNN layers for spatial feature extraction → LSTM for temporal patterns
- **Output**: Drought severity class (Normal / Mild / Moderate / Severe)

---

## 📊 Data Sources

| Dataset | Source | Resolution |
|---------|--------|------------|
| NDVI | MODIS MOD13A2 | 1km, 16-day |
| Rainfall | CHIRPS | 0.05°, monthly |
| Land Surface Temp | MODIS MOD11A2 | 1km, 8-day |
| Soil Moisture | SMAP | 9km, daily |

---

## 🗺️ Study Area

Default study area: **Maharashtra, India** (Vidarbha drought-prone region)
Easily configurable via `config.py`.

---

## 📈 Results

After training, evaluation metrics and plots are saved to `model/results/`.

---

## 👥 Authors

Major Project — [Your College Name]  
Department of [Your Department]  
Academic Year: 2024–25
