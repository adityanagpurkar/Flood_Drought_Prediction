# app/dashboard.py — DroughtWatch Streamlit Dashboard

"""
Interactive dashboard for drought prediction and monitoring.
Run with: streamlit run app/dashboard.py
"""

import os
import sys
import json
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime

import streamlit as st
import plotly.graph_objects as go
import folium
from streamlit_folium import st_folium

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import (
    REGION, MODEL_DIR, DATA_PROC_DIR, RESULTS_DIR,
    DROUGHT_CLASSES, DASHBOARD_TITLE, PAGE_ICON, SEQUENCE_LEN
)
from utils.visualize import (
    plot_time_series, plot_spi, plot_drought_distribution,
    plot_vhi, plot_confusion_matrix, plot_training_history
)
from utils.indices import compute_all_indices

# ─── Page Config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title=DASHBOARD_TITLE,
    page_icon=PAGE_ICON,
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── CSS Theme ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;600&display=swap');

html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif;
    background-color: #0d1117;
    color: #e6edf3;
}

h1, h2, h3 {
    font-family: 'Space Mono', monospace;
    letter-spacing: -0.5px;
}

.stApp { background-color: #0d1117; }

section[data-testid="stSidebar"] {
    background: #161b22;
    border-right: 1px solid #30363d;
}

.metric-card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 10px;
    padding: 18px 22px;
    text-align: center;
}
.metric-label {
    font-size: 0.75rem;
    color: #8b949e;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-family: 'Space Mono', monospace;
}
.metric-value {
    font-size: 2rem;
    font-weight: 700;
    font-family: 'Space Mono', monospace;
    margin: 6px 0 0;
}
.drought-badge {
    display: inline-block;
    padding: 4px 16px;
    border-radius: 20px;
    font-family: 'Space Mono', monospace;
    font-size: 0.85rem;
    font-weight: 700;
    letter-spacing: 1px;
}
.section-header {
    font-family: 'Space Mono', monospace;
    font-size: 0.7rem;
    letter-spacing: 3px;
    text-transform: uppercase;
    color: #8b949e;
    border-bottom: 1px solid #30363d;
    padding-bottom: 6px;
    margin: 24px 0 12px;
}
div[data-testid="stSelectbox"] label,
div[data-testid="stSlider"] label { color: #8b949e; font-size: 0.8rem; }
</style>
""", unsafe_allow_html=True)


# ─── Helpers ──────────────────────────────────────────────────────────────────

@st.cache_resource
def load_model():
    """Load TF model (cached)."""
    try:
        import tensorflow as tf
        path = os.path.join(MODEL_DIR, "best_model.keras")
        if not os.path.exists(path):
            path = os.path.join(MODEL_DIR, "model.h5")
        if os.path.exists(path):
            model = tf.keras.models.load_model(path)
            return model, True
    except Exception as e:
        st.warning(f"Model not loaded: {e}")
    return None, False


@st.cache_data
def load_data() -> pd.DataFrame:
    """Load processed monthly feature DataFrame."""
    path = os.path.join(DATA_PROC_DIR, "monthly_features.csv")
    if os.path.exists(path):
        return pd.read_csv(path)
    # Fallback: generate synthetic data
    from utils.preprocess import _generate_synthetic_data
    df = _generate_synthetic_data()
    df = compute_all_indices(df)
    return df


@st.cache_data
def load_metrics() -> dict | None:
    path = os.path.join(RESULTS_DIR, "metrics.json")
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return None


@st.cache_data
def load_history() -> dict | None:
    path = os.path.join(RESULTS_DIR, "history.json")
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return None


def get_drought_color(label: str) -> str:
    for _, v in DROUGHT_CLASSES.items():
        if v["label"] == label:
            return v["color"]
    return "#888"


# ─── Sidebar ──────────────────────────────────────────────────────────────────

def render_sidebar(df: pd.DataFrame):
    with st.sidebar:
        st.markdown(f"## {PAGE_ICON} DroughtWatch")
        st.markdown("**Maharashtra Drought Monitoring System**")
        st.markdown("---")

        page = st.radio("Navigation", [
            "🌍 Overview",
            "📈 Time Series Analysis",
            "🤖 Predict Drought",
            "🎯 Model Performance",
            "ℹ️ About",
        ])

        st.markdown("---")
        st.markdown('<div class="section-header">Study Area</div>', unsafe_allow_html=True)
        st.markdown(f"""
        📍 **{REGION['name']}**  
        🗓️ {df['date'].min()} → {df['date'].max()}  
        📊 {len(df)} monthly records
        """)

        st.markdown("---")
        # Current drought status
        latest = df.iloc[-1]
        status = latest.get("drought_class", "N/A")
        color  = get_drought_color(status)
        st.markdown("**Latest Status**")
        st.markdown(f"""
        <div style='text-align:center;margin-top:8px'>
            <span class='drought-badge' style='background:{color}20;color:{color};border:1px solid {color}'>
                {status.upper()}
            </span>
            <div style='font-size:0.75rem;color:#8b949e;margin-top:6px'>{latest['date']}</div>
        </div>
        """, unsafe_allow_html=True)

    return page


# ─── Overview Page ────────────────────────────────────────────────────────────

def page_overview(df: pd.DataFrame):
    st.title("🌾 DroughtWatch")
    st.markdown("#### Satellite-based Drought Prediction · Maharashtra, India")
    st.markdown("")

    # ── KPI cards ─────────────────────────────────────────────────────────────
    latest   = df.iloc[-1]
    avg_ndvi = df["ndvi"].mean()
    drought_pct = (df["drought_class"] != "Normal").mean() * 100
    severe_pct  = (df["drought_class"] == "Severe").mean() * 100

    c1, c2, c3, c4 = st.columns(4)
    cards = [
        (c1, "Current NDVI",     f"{latest['ndvi']:.3f}",        "#27ae60"),
        (c2, "Avg NDVI",         f"{avg_ndvi:.3f}",              "#3498db"),
        (c3, "Drought Months %", f"{drought_pct:.1f}%",          "#e67e22"),
        (c4, "Severe Months %",  f"{severe_pct:.1f}%",           "#e74c3c"),
    ]
    for col, label, value, color in cards:
        with col:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">{label}</div>
                <div class="metric-value" style="color:{color}">{value}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("")

    # ── Map + Drought distribution ─────────────────────────────────────────────
    col_map, col_pie = st.columns([3, 2])

    with col_map:
        st.markdown('<div class="section-header">Study Region</div>', unsafe_allow_html=True)
        m = folium.Map(
            location=REGION["center"],
            zoom_start=REGION["zoom"],
            tiles="CartoDB dark_matter",
        )
        folium.Rectangle(
            bounds=[[REGION["lat_min"], REGION["lon_min"]],
                    [REGION["lat_max"], REGION["lon_max"]]],
            color="#e67e22", weight=2, fill=True, fill_opacity=0.1,
            tooltip="Study Area: Maharashtra",
        ).add_to(m)

        # Color-coded recent drought markers (sample districts)
        districts = [
            ("Nagpur",    21.14, 79.09),
            ("Aurangabad",19.87, 75.34),
            ("Amravati",  20.93, 77.75),
            ("Nanded",    19.15, 77.31),
            ("Latur",     18.40, 76.56),
            ("Pune",      18.52, 73.86),
            ("Nashik",    19.99, 73.79),
        ]
        latest_class = latest.get("drought_class", "Normal")
        for name, lat, lon in districts:
            color = get_drought_color(latest_class)
            folium.CircleMarker(
                [lat, lon], radius=8,
                color=color, fill=True, fill_color=color, fill_opacity=0.7,
                tooltip=f"{name} — {latest_class}",
            ).add_to(m)

        st_folium(m, height=360, use_container_width=True)

    with col_pie:
        st.markdown('<div class="section-header">Drought Distribution</div>', unsafe_allow_html=True)
        st.plotly_chart(plot_drought_distribution(df),
                        use_container_width=True, config={"displayModeBar": False})

        # Legend
        st.markdown("")
        for _, v in DROUGHT_CLASSES.items():
            count = (df["drought_class"] == v["label"]).sum()
            pct   = count / len(df) * 100
            st.markdown(f"""
            <div style='display:flex;align-items:center;gap:10px;margin:4px 0'>
                <div style='width:12px;height:12px;border-radius:50%;background:{v["color"]}'></div>
                <span style='font-size:0.85rem'><b>{v["label"]}</b> — {count} months ({pct:.1f}%)</span>
            </div>
            """, unsafe_allow_html=True)

    # ── Recent data table ──────────────────────────────────────────────────────
    st.markdown('<div class="section-header">Recent Monthly Data</div>', unsafe_allow_html=True)
    display_cols = ["date", "ndvi", "rainfall", "lst", "SPI_3", "VHI", "drought_class"]
    display_cols = [c for c in display_cols if c in df.columns]
    recent = df[display_cols].tail(12).iloc[::-1].copy()

    def color_drought(val):
        colors = {"Normal": "#2ecc7120", "Mild": "#f1c40f20",
                  "Moderate": "#e67e2220", "Severe": "#e74c3c20"}
        return f"background-color: {colors.get(val, '')}"

    styled = recent.style.applymap(color_drought, subset=["drought_class"])
    styled = styled.format({
        "ndvi": "{:.3f}", "rainfall": "{:.1f}",
        "lst": "{:.1f}", "SPI_3": "{:.2f}", "VHI": "{:.1f}"
    })
    st.dataframe(styled, use_container_width=True, height=350)


# ─── Time Series Page ─────────────────────────────────────────────────────────

def page_time_series(df: pd.DataFrame):
    st.title("📈 Time Series Analysis")

    col1, col2 = st.columns([2, 1])
    with col1:
        spi_scale = st.selectbox("SPI Scale", [1, 3, 6, 12], index=1)
    with col2:
        year_range = st.slider(
            "Year Range",
            min_value=int(df["date"].str[:4].min()),
            max_value=int(df["date"].str[:4].max()),
            value=(int(df["date"].str[:4].min()), int(df["date"].str[:4].max()))
        )

    mask = (df["date"].str[:4].astype(int) >= year_range[0]) & \
           (df["date"].str[:4].astype(int) <= year_range[1])
    df_filtered = df[mask]

    st.plotly_chart(plot_time_series(df_filtered),
                    use_container_width=True, config={"displayModeBar": False})

    col_a, col_b = st.columns(2)
    with col_a:
        st.plotly_chart(plot_spi(df_filtered, scale=spi_scale),
                        use_container_width=True, config={"displayModeBar": False})
    with col_b:
        st.plotly_chart(plot_vhi(df_filtered),
                        use_container_width=True, config={"displayModeBar": False})


# ─── Prediction Page ──────────────────────────────────────────────────────────

def page_predict(df: pd.DataFrame):
    st.title("🤖 Predict Drought Condition")

    model, model_loaded = load_model()

    if not model_loaded:
        st.warning("⚠️ Trained model not found. Please run `python model/train.py` first.")
        st.info("For demo purposes, showing synthetic prediction below.")

    st.markdown("Enter the latest monthly satellite readings to predict drought severity.")
    st.markdown("")

    col1, col2, col3 = st.columns(3)
    with col1:
        ndvi     = st.slider("NDVI",      0.0,  1.0,  0.35, 0.01,
                             help="Normalized Difference Vegetation Index")
        rainfall = st.slider("Rainfall (mm)", 0.0, 400.0, 45.0, 1.0,
                             help="Monthly total precipitation")
    with col2:
        lst      = st.slider("LST (°C)",  15.0, 50.0, 32.0, 0.5,
                             help="Land Surface Temperature")
        spi      = st.slider("SPI-3",     -3.0,  3.0, -0.5, 0.1,
                             help="Standardized Precipitation Index (3-month)")
    with col3:
        vci      = st.slider("VCI",        0.0, 100.0, 35.0, 1.0,
                             help="Vegetation Condition Index")
        tci      = st.slider("TCI",        0.0, 100.0, 40.0, 1.0,
                             help="Temperature Condition Index")

    if st.button("🔍 Predict Drought Severity", type="primary"):
        with st.spinner("Analyzing satellite data..."):

            if model_loaded:
                # Build a sequence from last SEQUENCE_LEN-1 real rows + this input
                feat_cols = ["ndvi", "rainfall", "lst", "SPI_3", "VCI", "TCI", "VHI"]
                feat_cols = [c for c in feat_cols if c in df.columns]

                seq_data = df[feat_cols].tail(SEQUENCE_LEN - 1).values

                # Add the user-input row
                vhi_val = 0.5 * vci + 0.5 * tci
                new_row = np.array([ndvi, rainfall, lst, spi, vci, tci, vhi_val])
                new_row = new_row[:len(feat_cols)]

                # Pad if needed
                if len(new_row) < len(feat_cols):
                    new_row = np.pad(new_row, (0, len(feat_cols) - len(new_row)))

                seq = np.vstack([seq_data, new_row.reshape(1, -1)])
                if len(seq) < SEQUENCE_LEN:
                    pad = np.zeros((SEQUENCE_LEN - len(seq), len(feat_cols)))
                    seq = np.vstack([pad, seq])

                X = seq[-SEQUENCE_LEN:].reshape(1, SEQUENCE_LEN, len(feat_cols))

                # Scale (try to load scaler)
                import joblib
                scaler_path = os.path.join(DATA_PROC_DIR, "scaler.pkl")
                if os.path.exists(scaler_path):
                    scaler = joblib.load(scaler_path)
                    n_feat = X.shape[2]
                    if scaler.n_features_in_ == n_feat:
                        X = scaler.transform(X.reshape(-1, n_feat)).reshape(1, SEQUENCE_LEN, n_feat)

                proba = model.predict(X, verbose=0)[0]
                pred_class = int(np.argmax(proba))
            else:
                # Demo prediction from inputs
                if spi < -2.0 or ndvi < 0.15:
                    pred_class = 3
                elif spi < -1.5 or ndvi < 0.25:
                    pred_class = 2
                elif spi < -1.0 or ndvi < 0.35:
                    pred_class = 1
                else:
                    pred_class = 0
                proba = np.zeros(4); proba[pred_class] = 0.78
                proba[(pred_class + 1) % 4] = 0.15
                proba[(pred_class + 2) % 4] = 0.07

            label = DROUGHT_CLASSES[pred_class]["label"]
            color = DROUGHT_CLASSES[pred_class]["color"]

        # ── Result ────────────────────────────────────────────────────────────
        st.markdown("")
        res_col, prob_col = st.columns([1, 2])

        with res_col:
            st.markdown(f"""
            <div class="metric-card" style="border-color:{color}">
                <div class="metric-label">Predicted Drought Severity</div>
                <div class="metric-value" style="color:{color}; font-size:2.5rem">
                    {label.upper()}
                </div>
                <div style="color:#8b949e;font-size:0.8rem;margin-top:8px">
                    Confidence: {proba[pred_class]*100:.1f}%
                </div>
            </div>
            """, unsafe_allow_html=True)

            recommendations = {
                "Normal":   "✅ Conditions are normal. Routine monitoring advised.",
                "Mild":     "⚠️ Mild stress detected. Consider irrigation advisory.",
                "Moderate": "🔶 Moderate drought. Activate water conservation measures.",
                "Severe":   "🔴 Severe drought. Emergency response recommended.",
            }
            st.markdown("")
            st.info(recommendations[label])

        with prob_col:
            fig = go.Figure(go.Bar(
                x=[DROUGHT_CLASSES[i]["label"] for i in range(4)],
                y=proba * 100,
                marker_color=[DROUGHT_CLASSES[i]["color"] for i in range(4)],
                text=[f"{p*100:.1f}%" for p in proba],
                textposition="outside",
            ))
            fig.update_layout(
                title="Class Probability Distribution",
                yaxis_title="Probability (%)",
                yaxis_range=[0, 105],
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                height=280,
                margin=dict(l=20, r=20, t=50, b=20),
                font=dict(family="monospace"),
            )
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})


# ─── Model Performance Page ───────────────────────────────────────────────────

def page_performance():
    st.title("🎯 Model Performance")

    metrics = load_metrics()
    history = load_history()

    if metrics is None:
        st.warning("No evaluation metrics found. Run `python model/evaluate.py` after training.")
        return

    # KPI cards
    acc = metrics.get("test_accuracy", 0)
    f1  = metrics.get("weighted_f1", 0)
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(f"""<div class="metric-card">
            <div class="metric-label">Test Accuracy</div>
            <div class="metric-value" style="color:#2ecc71">{acc*100:.2f}%</div>
        </div>""", unsafe_allow_html=True)
    with c2:
        st.markdown(f"""<div class="metric-card">
            <div class="metric-label">Weighted F1</div>
            <div class="metric-value" style="color:#3498db">{f1:.4f}</div>
        </div>""", unsafe_allow_html=True)
    with c3:
        st.markdown(f"""<div class="metric-card">
            <div class="metric-label">Model</div>
            <div class="metric-value" style="color:#f1c40f;font-size:1rem;margin-top:14px">CNN-LSTM</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("")

    col_cm, col_hist = st.columns(2)

    with col_cm:
        cm = np.array(metrics["confusion_matrix"])
        st.plotly_chart(plot_confusion_matrix(cm),
                        use_container_width=True, config={"displayModeBar": False})

    with col_hist:
        if history:
            st.plotly_chart(plot_training_history(history),
                            use_container_width=True, config={"displayModeBar": False})
        else:
            st.info("Training history not available.")

    # Per-class report
    if "classification_report" in metrics:
        st.markdown('<div class="section-header">Per-class Report</div>', unsafe_allow_html=True)
        report = metrics["classification_report"]
        rows = []
        for cls in ["Normal", "Mild", "Moderate", "Severe"]:
            if cls in report:
                r = report[cls]
                rows.append({
                    "Class":     cls,
                    "Precision": f"{r['precision']:.3f}",
                    "Recall":    f"{r['recall']:.3f}",
                    "F1-Score":  f"{r['f1-score']:.3f}",
                    "Support":   int(r["support"]),
                })
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


# ─── About Page ───────────────────────────────────────────────────────────────

def page_about():
    st.title("ℹ️ About DroughtWatch")
    st.markdown("""
    ### Project Overview
    **DroughtWatch** is a deep learning-based drought prediction and monitoring system
    for the Maharashtra region of India, developed as a college major project.

    ---

    ### Methodology

    **Data Sources**
    - **MODIS MOD13A2** — NDVI at 1km resolution, 16-day composite
    - **CHIRPS** — Daily rainfall at 0.05° resolution
    - **MODIS MOD11A2** — Land Surface Temperature at 1km, 8-day

    **Drought Indices**
    - **SPI** (Standardized Precipitation Index) — rainfall anomaly
    - **VCI** (Vegetation Condition Index) — vegetation health
    - **TCI** (Temperature Condition Index) — thermal stress
    - **VHI** (Vegetation Health Index) — combined index

    **Model Architecture**
    ```
    Input (12 months × N features)
      ↓
    Conv1D (64) → Conv1D (128) → MaxPool → Dropout
      ↓
    LSTM (128, return_sequences) → Dropout
      ↓
    LSTM (64) → Dropout
      ↓
    Dense (64) → Dense (32)
      ↓
    Softmax (4 classes)
    ```

    **Drought Classes**
    | Class | SPI Range | Interpretation |
    |---|---|---|
    | Normal | ≥ -1.0 | Adequate moisture |
    | Mild | -1.5 to -1.0 | Moderate water stress |
    | Moderate | -2.0 to -1.5 | Significant drought |
    | Severe | < -2.0 | Extreme drought conditions |

    ---

    ### Tech Stack
    `TensorFlow/Keras` · `Streamlit` · `Google Earth Engine` · `Rasterio` · `Xarray` · `Plotly` · `Folium`
    """)


# ─── Main Router ──────────────────────────────────────────────────────────────

def main():
    df = load_data()
    page = render_sidebar(df)

    if page == "🌍 Overview":
        page_overview(df)
    elif page == "📈 Time Series Analysis":
        page_time_series(df)
    elif page == "🤖 Predict Drought":
        page_predict(df)
    elif page == "🎯 Model Performance":
        page_performance()
    elif page == "ℹ️ About":
        page_about()


if __name__ == "__main__":
    main()
