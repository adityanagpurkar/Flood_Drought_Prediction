# config.py — Global Configuration for Drought Prediction System

import os

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR        = os.path.dirname(os.path.abspath(__file__))
DATA_RAW_DIR    = os.path.join(BASE_DIR, "data", "raw")
DATA_PROC_DIR   = os.path.join(BASE_DIR, "data", "processed")
MODEL_DIR       = os.path.join(BASE_DIR, "model", "saved_model")
RESULTS_DIR     = os.path.join(BASE_DIR, "model", "results")

for d in [DATA_RAW_DIR, DATA_PROC_DIR, MODEL_DIR, RESULTS_DIR]:
    os.makedirs(d, exist_ok=True)

# ─── Study Area (Maharashtra / Vidarbha) ──────────────────────────────────────
REGION = {
    "name":     "Maharashtra, India",
    "lon_min":  72.6,
    "lat_min":  15.6,
    "lon_max":  80.9,
    "lat_max":  22.1,
    "center":   [19.7515, 75.7139],   # for folium map
    "zoom":     6,
}

# ─── Google Earth Engine ──────────────────────────────────────────────────────
GEE_PROJECT     = "your-gee-project-id"   # ← replace with your GEE project
START_DATE      = "2015-01-01"
END_DATE        = "2023-12-31"

# MODIS NDVI
NDVI_COLLECTION = "MODIS/061/MOD13A2"
NDVI_BAND       = "NDVI"
NDVI_SCALE      = 0.0001               # scale factor

# CHIRPS Rainfall
RAIN_COLLECTION = "UCSB-CHG/CHIRPS/DAILY"
RAIN_BAND       = "precipitation"

# MODIS Land Surface Temperature
LST_COLLECTION  = "MODIS/061/MOD11A2"
LST_BAND        = "LST_Day_1km"
LST_SCALE       = 0.02                 # Kelvin scale factor

# ─── Model Hyperparameters ────────────────────────────────────────────────────
SEQUENCE_LEN    = 12       # months of history used as input window
FEATURES        = ["ndvi", "rainfall", "lst", "spi"]
N_FEATURES      = len(FEATURES)
N_CLASSES       = 4        # Normal, Mild, Moderate, Severe

EPOCHS          = 50
BATCH_SIZE      = 32
LEARNING_RATE   = 1e-3
VALIDATION_SPLIT = 0.2
TEST_SPLIT      = 0.1
RANDOM_SEED     = 42

# CNN-LSTM architecture
CNN_FILTERS     = [64, 128]
CNN_KERNEL      = 3
LSTM_UNITS      = [128, 64]
DENSE_UNITS     = [64, 32]
DROPOUT_RATE    = 0.3

# ─── Drought Classification Thresholds (SPI-based) ───────────────────────────
DROUGHT_CLASSES = {
    0: {"label": "Normal",   "spi_range": (0.0,  99), "color": "#2ecc71"},
    1: {"label": "Mild",     "spi_range": (-1.0,  0.0), "color": "#f1c40f"},
    2: {"label": "Moderate", "spi_range": (-1.5, -1.0), "color": "#e67e22"},
    3: {"label": "Severe",   "spi_range": (-99,  -1.5), "color": "#e74c3c"},
}

# ─── Dashboard ────────────────────────────────────────────────────────────────
DASHBOARD_TITLE = "DroughtWatch — Satellite-based Drought Prediction"
PAGE_ICON       = "🌾"
