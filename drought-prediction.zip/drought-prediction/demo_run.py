# demo_run.py — Run dashboard with synthetic data (no GEE required)
"""
Quick demo that generates synthetic data, trains a fast model,
and launches the Streamlit dashboard — all in one command.

Usage:
    python demo_run.py
"""

import os
import sys
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).parent

def run(cmd: str):
    print(f"\n$ {cmd}")
    result = subprocess.run(cmd, shell=True, cwd=str(BASE_DIR))
    if result.returncode != 0:
        print(f"⚠️  Command exited with code {result.returncode}")
    return result.returncode


def main():
    print("=" * 55)
    print("  DroughtWatch — Demo Run (Synthetic Data)")
    print("=" * 55)

    # Step 1: Preprocess (generates synthetic data automatically)
    print("\n[1/3] Preprocessing data...")
    run("python utils/preprocess.py")

    # Step 2: Train (reduced epochs for demo)
    print("\n[2/3] Training model (demo — 10 epochs)...")
    os.environ["DROUGHT_DEMO_EPOCHS"] = "10"
    run("python model/train.py")

    # Step 3: Evaluate
    print("\n[3/3] Evaluating model...")
    run("python model/evaluate.py")

    # Step 4: Launch dashboard
    print("\n🚀 Launching Dashboard...")
    print("   Open: http://localhost:8501\n")
    run("streamlit run app/dashboard.py")


if __name__ == "__main__":
    main()
