# model/evaluate.py — Model Evaluation & Metrics

"""
Loads the trained model and evaluates it on the test set.
Generates classification report, confusion matrix, and plots.

Usage:
    python model/evaluate.py
"""

import os
import sys
import json
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

import tensorflow as tf
from sklearn.metrics import (
    classification_report, confusion_matrix,
    accuracy_score, f1_score
)

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import MODEL_DIR, DATA_PROC_DIR, RESULTS_DIR


CLASS_NAMES = ["Normal", "Mild", "Moderate", "Severe"]


def load_model_and_data():
    """Load best model and test data."""
    model_path = os.path.join(MODEL_DIR, "best_model.keras")
    if not os.path.exists(model_path):
        model_path = os.path.join(MODEL_DIR, "model.h5")

    if not os.path.exists(model_path):
        raise FileNotFoundError("No saved model found. Run train.py first.")

    model = tf.keras.models.load_model(model_path)
    print(f"✅ Model loaded: {model_path}")

    data = np.load(os.path.join(DATA_PROC_DIR, "sequences.npz"), allow_pickle=True)
    return model, data["X_test"], data["y_test"]


def evaluate():
    os.makedirs(RESULTS_DIR, exist_ok=True)

    model, X_test, y_test = load_model_and_data()

    # ── Predictions ───────────────────────────────────────────────────────────
    y_pred_proba = model.predict(X_test, verbose=0)
    y_pred = np.argmax(y_pred_proba, axis=1)

    # ── Metrics ───────────────────────────────────────────────────────────────
    acc = accuracy_score(y_test, y_pred)
    f1  = f1_score(y_test, y_pred, average="weighted")
    cm  = confusion_matrix(y_test, y_pred)

    print(f"\n{'='*50}")
    print(f"  Test Accuracy : {acc:.4f} ({acc*100:.2f}%)")
    print(f"  Weighted F1   : {f1:.4f}")
    print(f"{'='*50}\n")
    print(classification_report(y_test, y_pred, target_names=CLASS_NAMES))

    # ── Save metrics ──────────────────────────────────────────────────────────
    metrics = {
        "test_accuracy": round(float(acc), 4),
        "weighted_f1":   round(float(f1), 4),
        "confusion_matrix": cm.tolist(),
        "classification_report": classification_report(
            y_test, y_pred, target_names=CLASS_NAMES, output_dict=True
        ),
    }
    metrics_path = os.path.join(RESULTS_DIR, "metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"📊 Metrics saved: {metrics_path}")

    # ── Confusion Matrix Plot ─────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
    plt.colorbar(im)
    ax.set_xticks(range(len(CLASS_NAMES)))
    ax.set_yticks(range(len(CLASS_NAMES)))
    ax.set_xticklabels(CLASS_NAMES, rotation=45, ha="right")
    ax.set_yticklabels(CLASS_NAMES)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion Matrix — Test Set")

    for i in range(len(CLASS_NAMES)):
        for j in range(len(CLASS_NAMES)):
            ax.text(j, i, str(cm[i, j]),
                    ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")

    plt.tight_layout()
    cm_path = os.path.join(RESULTS_DIR, "confusion_matrix.png")
    plt.savefig(cm_path, dpi=150)
    plt.close()
    print(f"🖼️  Confusion matrix saved: {cm_path}")

    # ── Training History Plot ─────────────────────────────────────────────────
    hist_path = os.path.join(RESULTS_DIR, "history.json")
    if os.path.exists(hist_path):
        with open(hist_path) as f:
            history = json.load(f)

        fig, axes = plt.subplots(1, 2, figsize=(12, 4))
        epochs = range(1, len(history["loss"]) + 1)

        axes[0].plot(epochs, history["loss"],     "r-",  label="Train Loss")
        axes[0].plot(epochs, history["val_loss"], "r--", label="Val Loss")
        axes[0].set_title("Loss"); axes[0].legend(); axes[0].grid(True)

        axes[1].plot(epochs, history["accuracy"],     "b-",  label="Train Acc")
        axes[1].plot(epochs, history["val_accuracy"], "b--", label="Val Acc")
        axes[1].set_title("Accuracy"); axes[1].legend(); axes[1].grid(True)

        plt.suptitle("Training History")
        plt.tight_layout()
        hist_plot = os.path.join(RESULTS_DIR, "training_history.png")
        plt.savefig(hist_plot, dpi=150)
        plt.close()
        print(f"🖼️  Training history saved: {hist_plot}")

    return metrics


if __name__ == "__main__":
    evaluate()
