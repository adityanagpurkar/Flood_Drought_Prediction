# model/train.py — CNN-LSTM Model Training

"""
Builds, trains, and saves the CNN-LSTM drought prediction model.

Architecture:
  Input (seq_len, n_features)
    → Conv1D (64 filters) → Conv1D (128 filters) → MaxPooling
    → LSTM (128 units) → LSTM (64 units)
    → Dense (64) → Dropout → Dense (32)
    → Output (4 classes, softmax)

Usage:
    python model/train.py
"""

import os
import sys
import json
import numpy as np
from pathlib import Path

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, callbacks
from sklearn.utils.class_weight import compute_class_weight

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import (
    DATA_PROC_DIR, MODEL_DIR, RESULTS_DIR,
    SEQUENCE_LEN, N_FEATURES, N_CLASSES,
    CNN_FILTERS, CNN_KERNEL, LSTM_UNITS, DENSE_UNITS,
    DROPOUT_RATE, LEARNING_RATE, EPOCHS, BATCH_SIZE, RANDOM_SEED
)

tf.random.set_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)


# ─── Build Model ──────────────────────────────────────────────────────────────

def build_cnn_lstm(seq_len: int, n_features: int, n_classes: int) -> keras.Model:
    """
    Build the CNN-LSTM hybrid model for drought classification.
    """
    inputs = keras.Input(shape=(seq_len, n_features), name="input")

    # ── CNN Block ──────────────────────────────────────────────────────────────
    x = layers.Conv1D(CNN_FILTERS[0], CNN_KERNEL,
                      activation="relu", padding="same",
                      name="conv1")(inputs)
    x = layers.BatchNormalization(name="bn1")(x)

    x = layers.Conv1D(CNN_FILTERS[1], CNN_KERNEL,
                      activation="relu", padding="same",
                      name="conv2")(x)
    x = layers.BatchNormalization(name="bn2")(x)
    x = layers.MaxPooling1D(pool_size=2, name="pool1")(x)
    x = layers.Dropout(DROPOUT_RATE / 2, name="drop_cnn")(x)

    # ── LSTM Block ─────────────────────────────────────────────────────────────
    x = layers.LSTM(LSTM_UNITS[0], return_sequences=True,
                    name="lstm1")(x)
    x = layers.Dropout(DROPOUT_RATE, name="drop_lstm1")(x)

    x = layers.LSTM(LSTM_UNITS[1], return_sequences=False,
                    name="lstm2")(x)
    x = layers.Dropout(DROPOUT_RATE, name="drop_lstm2")(x)

    # ── Dense Head ────────────────────────────────────────────────────────────
    x = layers.Dense(DENSE_UNITS[0], activation="relu",
                     kernel_regularizer=keras.regularizers.l2(1e-4),
                     name="dense1")(x)
    x = layers.Dropout(DROPOUT_RATE / 2, name="drop_dense")(x)

    x = layers.Dense(DENSE_UNITS[1], activation="relu",
                     name="dense2")(x)

    outputs = layers.Dense(n_classes, activation="softmax",
                           name="output")(x)

    model = keras.Model(inputs, outputs, name="DroughtCNN_LSTM")
    return model


# ─── Load Data ────────────────────────────────────────────────────────────────

def load_processed_data():
    """Load preprocessed sequences from data/processed/."""
    path = os.path.join(DATA_PROC_DIR, "sequences.npz")

    if not os.path.exists(path):
        print("⚠️  Processed data not found. Running preprocessing first...")
        from utils.preprocess import run_preprocessing
        run_preprocessing()

    data = np.load(path, allow_pickle=True)
    return (
        data["X_train"], data["y_train"],
        data["X_val"],   data["y_val"],
        data["X_test"],  data["y_test"],
        data["feature_names"].tolist(),
    )


# ─── Train ────────────────────────────────────────────────────────────────────

def train():
    print("🧠 Loading data...")
    X_train, y_train, X_val, y_val, X_test, y_test, feat_names = load_processed_data()

    seq_len    = X_train.shape[1]
    n_features = X_train.shape[2]
    print(f"   X_train: {X_train.shape}  | Classes: {np.unique(y_train)}")
    print(f"   Features ({n_features}): {feat_names}\n")

    # ── Class weights for imbalanced data ─────────────────────────────────────
    classes = np.unique(y_train)
    weights = compute_class_weight("balanced", classes=classes, y=y_train)
    class_weight = dict(zip(classes, weights))
    print(f"   Class weights: {class_weight}\n")

    # ── Build model ───────────────────────────────────────────────────────────
    model = build_cnn_lstm(seq_len, n_features, N_CLASSES)
    model.summary()

    # ── Compile ───────────────────────────────────────────────────────────────
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=LEARNING_RATE),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )

    # ── Callbacks ─────────────────────────────────────────────────────────────
    os.makedirs(MODEL_DIR, exist_ok=True)
    best_model_path = os.path.join(MODEL_DIR, "best_model.keras")

    cb_list = [
        callbacks.ModelCheckpoint(
            best_model_path, monitor="val_accuracy",
            save_best_only=True, verbose=1,
        ),
        callbacks.EarlyStopping(
            monitor="val_loss", patience=10,
            restore_best_weights=True, verbose=1,
        ),
        callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5,
            patience=5, min_lr=1e-6, verbose=1,
        ),
        callbacks.TensorBoard(
            log_dir=os.path.join(RESULTS_DIR, "tensorboard"),
            histogram_freq=1,
        ),
    ]

    # ── Train ─────────────────────────────────────────────────────────────────
    print("\n🚀 Training...\n")
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        class_weight=class_weight,
        callbacks=cb_list,
        verbose=1,
    )

    # ── Save history ──────────────────────────────────────────────────────────
    hist_path = os.path.join(RESULTS_DIR, "history.json")
    with open(hist_path, "w") as f:
        json.dump({k: [float(v) for v in vals]
                   for k, vals in history.history.items()}, f, indent=2)
    print(f"\n📊 Training history saved: {hist_path}")

    # ── Also save as .h5 for compatibility ────────────────────────────────────
    h5_path = os.path.join(MODEL_DIR, "model.h5")
    model.save(h5_path)
    print(f"💾 Model saved (h5): {h5_path}")

    # ── Save feature names ────────────────────────────────────────────────────
    import json
    meta = {
        "feature_names": feat_names,
        "seq_len": int(seq_len),
        "n_features": int(n_features),
        "n_classes": N_CLASSES,
        "class_map": {0: "Normal", 1: "Mild", 2: "Moderate", 3: "Severe"},
    }
    meta_path = os.path.join(MODEL_DIR, "model_meta.json")
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    print(f"📝 Model metadata saved: {meta_path}")

    return model, history


if __name__ == "__main__":
    train()
