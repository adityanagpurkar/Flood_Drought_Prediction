@echo off
REM ─────────────────────────────────────────────────────────
REM  DroughtWatch — Windows Setup Script
REM  Run this once to set up your environment
REM ─────────────────────────────────────────────────────────

echo.
echo ============================================
echo  DroughtWatch Setup — Windows
echo ============================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.10+ from python.org
    pause
    exit /b 1
)

REM Create virtual environment
echo [1/5] Creating virtual environment...
python -m venv venv
call venv\Scripts\activate.bat

REM Upgrade pip
echo [2/5] Upgrading pip...
python -m pip install --upgrade pip

REM Install dependencies
echo [3/5] Installing dependencies...
pip install -r requirements.txt

REM Authenticate GEE
echo.
echo [4/5] Google Earth Engine Authentication
echo        (A browser window will open — sign in with your Google account)
echo        Skip this step if you already authenticated.
echo.
set /p gee_auth="Authenticate GEE now? (y/n): "
if /i "%gee_auth%"=="y" (
    earthengine authenticate
)

REM Create directories
echo [5/5] Creating data directories...
mkdir data\raw 2>nul
mkdir data\processed 2>nul
mkdir model\saved_model 2>nul
mkdir model\results 2>nul

echo.
echo ============================================
echo  Setup Complete!
echo ============================================
echo.
echo Next steps:
echo   1. Edit config.py — set your GEE project ID and region
echo   2. python utils/gee_fetch.py      — fetch satellite data
echo   3. python utils/preprocess.py     — preprocess data
echo   4. python model/train.py          — train the model
echo   5. python model/evaluate.py       — evaluate performance
echo   6. streamlit run app/dashboard.py — launch dashboard
echo.
pause
