# utils/gee_fetch.py — Fetch satellite data from Google Earth Engine

"""
Fetches NDVI, Rainfall, and LST data for the study region using GEE Python API.
Saves monthly composites as GeoTIFF files in data/raw/.

Usage:
    python utils/gee_fetch.py
"""

import ee
import os
import sys
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import (
    GEE_PROJECT, START_DATE, END_DATE, REGION,
    NDVI_COLLECTION, NDVI_BAND, NDVI_SCALE,
    RAIN_COLLECTION, RAIN_BAND,
    LST_COLLECTION, LST_BAND, LST_SCALE,
    DATA_RAW_DIR
)


def initialize_gee():
    """Authenticate and initialize Google Earth Engine."""
    try:
        ee.Initialize(project=GEE_PROJECT)
        print("✅ Google Earth Engine initialized successfully.")
    except Exception:
        print("🔑 GEE not authenticated. Running: earthengine authenticate")
        ee.Authenticate()
        ee.Initialize(project=GEE_PROJECT)


def get_region_geometry():
    """Return GEE geometry for the study area."""
    return ee.Geometry.Rectangle([
        REGION["lon_min"], REGION["lat_min"],
        REGION["lon_max"], REGION["lat_max"]
    ])


def fetch_ndvi_monthly(year: int, month: int, geometry) -> np.ndarray | None:
    """Fetch mean monthly NDVI composite for given year/month."""
    start = f"{year}-{month:02d}-01"
    end_date = datetime(year, month, 1) + relativedelta(months=1)
    end = end_date.strftime("%Y-%m-%d")

    collection = (
        ee.ImageCollection(NDVI_COLLECTION)
        .filterDate(start, end)
        .filterBounds(geometry)
        .select(NDVI_BAND)
    )

    image = collection.mean().multiply(NDVI_SCALE).rename("ndvi")
    return _export_to_numpy(image, geometry, scale=1000, label=f"NDVI {year}-{month:02d}")


def fetch_rainfall_monthly(year: int, month: int, geometry) -> np.ndarray | None:
    """Fetch total monthly rainfall (CHIRPS) for given year/month."""
    start = f"{year}-{month:02d}-01"
    end_date = datetime(year, month, 1) + relativedelta(months=1)
    end = end_date.strftime("%Y-%m-%d")

    collection = (
        ee.ImageCollection(RAIN_COLLECTION)
        .filterDate(start, end)
        .filterBounds(geometry)
        .select(RAIN_BAND)
    )

    image = collection.sum().rename("rainfall")
    return _export_to_numpy(image, geometry, scale=5000, label=f"Rain {year}-{month:02d}")


def fetch_lst_monthly(year: int, month: int, geometry) -> np.ndarray | None:
    """Fetch mean monthly Land Surface Temperature (MODIS) in Celsius."""
    start = f"{year}-{month:02d}-01"
    end_date = datetime(year, month, 1) + relativedelta(months=1)
    end = end_date.strftime("%Y-%m-%d")

    collection = (
        ee.ImageCollection(LST_COLLECTION)
        .filterDate(start, end)
        .filterBounds(geometry)
        .select(LST_BAND)
    )

    # Convert from DN to Kelvin to Celsius
    image = collection.mean().multiply(LST_SCALE).subtract(273.15).rename("lst")
    return _export_to_numpy(image, geometry, scale=1000, label=f"LST {year}-{month:02d}")


def _export_to_numpy(image, geometry, scale: int, label: str) -> np.ndarray | None:
    """Download a GEE image as a numpy array (getDownloadURL method)."""
    try:
        import urllib.request
        import zipfile
        import io
        import rasterio

        url = image.getDownloadURL({
            "scale": scale,
            "region": geometry,
            "format": "GEO_TIFF",
            "filePerBand": False,
        })

        with urllib.request.urlopen(url) as response:
            data = response.read()

        with rasterio.open(io.BytesIO(data)) as src:
            arr = src.read(1).astype(np.float32)
            arr[arr == src.nodata] = np.nan

        print(f"  ✓ {label}")
        return arr

    except Exception as e:
        print(f"  ✗ {label}: {e}")
        return None


def fetch_all_data():
    """
    Fetch NDVI, Rainfall, and LST for every month in the configured date range.
    Saves stacked numpy arrays per year to data/raw/.
    """
    initialize_gee()
    geometry = get_region_geometry()

    start = datetime.strptime(START_DATE, "%Y-%m-%d")
    end   = datetime.strptime(END_DATE,   "%Y-%m-%d")

    records = []
    current = start

    print(f"\n📡 Fetching data: {START_DATE} → {END_DATE}")
    print(f"📍 Region: {REGION['name']}\n")

    while current <= end:
        y, m = current.year, current.month
        print(f"[{y}-{m:02d}]")

        ndvi     = fetch_ndvi_monthly(y, m, geometry)
        rainfall = fetch_rainfall_monthly(y, m, geometry)
        lst      = fetch_lst_monthly(y, m, geometry)

        records.append({
            "year":     y,
            "month":    m,
            "ndvi":     ndvi,
            "rainfall": rainfall,
            "lst":      lst,
        })

        current += relativedelta(months=1)

    # ── Save as compressed numpy archive ──────────────────────────────────────
    out_path = os.path.join(DATA_RAW_DIR, "satellite_data.npz")
    np.savez_compressed(
        out_path,
        ndvi=np.array([r["ndvi"]     for r in records], dtype=object),
        rainfall=np.array([r["rainfall"] for r in records], dtype=object),
        lst=np.array([r["lst"]      for r in records], dtype=object),
        dates=np.array([f"{r['year']}-{r['month']:02d}" for r in records]),
    )
    print(f"\n✅ Data saved to: {out_path}")

    # ── Save a CSV metadata file ───────────────────────────────────────────────
    meta = pd.DataFrame([
        {"date": f"{r['year']}-{r['month']:02d}",
         "ndvi_mean":     np.nanmean(r["ndvi"])     if r["ndvi"]     is not None else None,
         "rainfall_mean": np.nanmean(r["rainfall"]) if r["rainfall"] is not None else None,
         "lst_mean":      np.nanmean(r["lst"])      if r["lst"]      is not None else None}
        for r in records
    ])
    meta_path = os.path.join(DATA_RAW_DIR, "monthly_means.csv")
    meta.to_csv(meta_path, index=False)
    print(f"✅ Monthly means saved to: {meta_path}\n")


if __name__ == "__main__":
    fetch_all_data()
