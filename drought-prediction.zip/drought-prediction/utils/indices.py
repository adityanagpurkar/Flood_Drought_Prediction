# utils/indices.py — Drought Index Calculations

"""
Computes standard drought indices:
  - SPI  : Standardized Precipitation Index
  - VCI  : Vegetation Condition Index (from NDVI)
  - TCI  : Temperature Condition Index (from LST)
  - VHI  : Vegetation Health Index (combined VCI + TCI)
"""

import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import gamma


# ─── SPI — Standardized Precipitation Index ───────────────────────────────────

def compute_spi(rainfall_series: pd.Series, scale: int = 3) -> pd.Series:
    """
    Compute SPI for a monthly rainfall time series.

    Parameters
    ----------
    rainfall_series : pd.Series
        Monthly rainfall values (mm).
    scale : int
        Accumulation period in months (1, 3, 6, 12 are standard).

    Returns
    -------
    pd.Series of SPI values (same length, NaN for first scale-1 months).
    """
    # Rolling sum over scale months
    rain_accum = rainfall_series.rolling(window=scale).sum()

    spi_values = np.full(len(rainfall_series), np.nan)

    # Fit gamma distribution to non-zero, non-NaN values
    valid = rain_accum.dropna()
    valid = valid[valid > 0]

    if len(valid) < 10:
        return pd.Series(spi_values, index=rainfall_series.index)

    # Gamma fit
    alpha, loc, beta = stats.gamma.fit(valid, floc=0)

    # For each accumulated value, compute CDF then convert to normal Z-score
    for i, val in enumerate(rain_accum):
        if np.isnan(val):
            continue
        if val == 0:
            # P(X=0) estimated by proportion of zeros
            p_zero = (rainfall_series[:i+1] == 0).sum() / (i + 1)
            cdf = p_zero
        else:
            cdf = stats.gamma.cdf(val, alpha, loc=loc, scale=beta)
            p_zero = (rainfall_series[:i+1] == 0).sum() / (i + 1)
            cdf = p_zero + (1 - p_zero) * cdf

        # Avoid edge cases
        cdf = np.clip(cdf, 1e-6, 1 - 1e-6)
        spi_values[i] = stats.norm.ppf(cdf)

    return pd.Series(spi_values, index=rainfall_series.index, name=f"SPI_{scale}")


# ─── VCI — Vegetation Condition Index ─────────────────────────────────────────

def compute_vci(ndvi_series: pd.Series,
                window: int = 36) -> pd.Series:
    """
    VCI = (NDVI - NDVI_min) / (NDVI_max - NDVI_min) * 100
    Uses a rolling window to compute min/max to capture seasonality.

    Parameters
    ----------
    ndvi_series : pd.Series
        Monthly mean NDVI values.
    window : int
        Rolling window size in months (default 36 = 3 years).

    Returns
    -------
    pd.Series of VCI values (0–100).
    """
    ndvi_min = ndvi_series.rolling(window=window, min_periods=6).min()
    ndvi_max = ndvi_series.rolling(window=window, min_periods=6).max()

    denom = ndvi_max - ndvi_min
    denom = denom.replace(0, np.nan)  # avoid division by zero

    vci = (ndvi_series - ndvi_min) / denom * 100
    vci = vci.clip(0, 100)
    return vci.rename("VCI")


# ─── TCI — Temperature Condition Index ────────────────────────────────────────

def compute_tci(lst_series: pd.Series,
                window: int = 36) -> pd.Series:
    """
    TCI = (LST_max - LST) / (LST_max - LST_min) * 100
    Higher temperature → lower TCI → more stress.

    Parameters
    ----------
    lst_series : pd.Series
        Monthly mean Land Surface Temperature (°C).
    window : int
        Rolling window size in months.

    Returns
    -------
    pd.Series of TCI values (0–100).
    """
    lst_min = lst_series.rolling(window=window, min_periods=6).min()
    lst_max = lst_series.rolling(window=window, min_periods=6).max()

    denom = lst_max - lst_min
    denom = denom.replace(0, np.nan)

    tci = (lst_max - lst_series) / denom * 100
    tci = tci.clip(0, 100)
    return tci.rename("TCI")


# ─── VHI — Vegetation Health Index ────────────────────────────────────────────

def compute_vhi(vci: pd.Series,
                tci: pd.Series,
                alpha: float = 0.5) -> pd.Series:
    """
    VHI = alpha * VCI + (1 - alpha) * TCI

    Parameters
    ----------
    vci : pd.Series
        Vegetation Condition Index.
    tci : pd.Series
        Temperature Condition Index.
    alpha : float
        Weight for VCI (default 0.5 — equal weight).

    Returns
    -------
    pd.Series of VHI values (0–100).
    """
    vhi = alpha * vci + (1 - alpha) * tci
    return vhi.rename("VHI")


# ─── Drought Label from SPI ────────────────────────────────────────────────────

def spi_to_label(spi_value: float) -> int:
    """
    Convert SPI value to drought class label.

    Returns
    -------
    int : 0=Normal, 1=Mild, 2=Moderate, 3=Severe
    """
    if np.isnan(spi_value):
        return 0
    if spi_value >= -1.0:
        return 0   # Normal
    elif spi_value >= -1.5:
        return 1   # Mild
    elif spi_value >= -2.0:
        return 2   # Moderate
    else:
        return 3   # Severe


def assign_drought_labels(df: pd.DataFrame,
                          spi_col: str = "SPI_3") -> pd.DataFrame:
    """Add a 'drought_label' column to a DataFrame based on SPI."""
    df = df.copy()
    df["drought_label"] = df[spi_col].apply(spi_to_label)
    df["drought_class"] = df["drought_label"].map({
        0: "Normal", 1: "Mild", 2: "Moderate", 3: "Severe"
    })
    return df


# ─── Compute All Indices from Monthly DataFrame ────────────────────────────────

def compute_all_indices(df: pd.DataFrame) -> pd.DataFrame:
    """
    Expects df with columns: ['date', 'ndvi', 'rainfall', 'lst']
    Returns df with all indices added.
    """
    df = df.copy()
    df = df.sort_values("date").reset_index(drop=True)

    # SPI at 1, 3, 6 month scales
    for scale in [1, 3, 6]:
        df[f"SPI_{scale}"] = compute_spi(df["rainfall"], scale=scale).values

    df["VCI"] = compute_vci(df["ndvi"]).values
    df["TCI"] = compute_tci(df["lst"]).values
    df["VHI"] = compute_vhi(df["VCI"], df["TCI"]).values

    # Use SPI-3 as the labeling source
    df = assign_drought_labels(df, spi_col="SPI_3")

    return df


if __name__ == "__main__":
    # Quick test with synthetic data
    np.random.seed(42)
    dates = pd.date_range("2015-01-01", "2023-12-01", freq="MS")
    test_df = pd.DataFrame({
        "date":     dates.strftime("%Y-%m"),
        "ndvi":     np.random.uniform(0.1, 0.7, len(dates)),
        "rainfall": np.random.exponential(50, len(dates)),
        "lst":      np.random.uniform(20, 45, len(dates)),
    })

    result = compute_all_indices(test_df)
    print(result[["date", "ndvi", "rainfall", "SPI_3", "VCI", "TCI", "VHI", "drought_class"]].tail(20))
