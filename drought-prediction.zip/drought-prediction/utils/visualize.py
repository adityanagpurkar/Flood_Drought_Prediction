# utils/visualize.py — Visualization Utilities

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

# ─── Color palette ────────────────────────────────────────────────────────────
DROUGHT_COLORS = {
    "Normal":   "#2ecc71",
    "Mild":     "#f1c40f",
    "Moderate": "#e67e22",
    "Severe":   "#e74c3c",
}
CLASS_ORDER = ["Normal", "Mild", "Moderate", "Severe"]


# ─── Time Series ──────────────────────────────────────────────────────────────

def plot_time_series(df: pd.DataFrame) -> go.Figure:
    """
    Interactive Plotly time series of NDVI, Rainfall, LST with drought coloring.
    """
    fig = make_subplots(
        rows=3, cols=1,
        shared_xaxes=True,
        subplot_titles=("NDVI (Vegetation Index)", "Rainfall (mm)", "Land Surface Temp (°C)"),
        vertical_spacing=0.08,
    )

    colors = [DROUGHT_COLORS.get(c, "#888") for c in df.get("drought_class", ["Normal"] * len(df))]
    dates = df["date"].astype(str).tolist()

    # NDVI
    fig.add_trace(go.Scatter(x=dates, y=df["ndvi"], mode="lines+markers",
                             line=dict(color="#27ae60", width=2),
                             marker=dict(color=colors, size=6),
                             name="NDVI"), row=1, col=1)

    # Rainfall
    fig.add_trace(go.Bar(x=dates, y=df["rainfall"],
                         marker_color=colors,
                         name="Rainfall"), row=2, col=1)

    # LST
    fig.add_trace(go.Scatter(x=dates, y=df["lst"], mode="lines",
                             line=dict(color="#e74c3c", width=2),
                             name="LST"), row=3, col=1)

    fig.update_layout(
        height=600,
        showlegend=False,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="monospace"),
        margin=dict(l=20, r=20, t=40, b=20),
    )
    fig.update_xaxes(showgrid=True, gridcolor="#222")
    fig.update_yaxes(showgrid=True, gridcolor="#222")

    return fig


# ─── SPI Chart ────────────────────────────────────────────────────────────────

def plot_spi(df: pd.DataFrame, scale: int = 3) -> go.Figure:
    """Bar chart of SPI values colored by drought class."""
    col = f"SPI_{scale}"
    if col not in df.columns:
        return go.Figure()

    colors = [DROUGHT_COLORS["Normal"] if v >= -1
              else DROUGHT_COLORS["Mild"] if v >= -1.5
              else DROUGHT_COLORS["Moderate"] if v >= -2
              else DROUGHT_COLORS["Severe"]
              for v in df[col].fillna(0)]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=df["date"].astype(str),
        y=df[col],
        marker_color=colors,
        name=f"SPI-{scale}",
    ))
    fig.add_hline(y=-1.0, line_dash="dash", line_color=DROUGHT_COLORS["Mild"],
                  annotation_text="Mild threshold")
    fig.add_hline(y=-1.5, line_dash="dash", line_color=DROUGHT_COLORS["Moderate"],
                  annotation_text="Moderate threshold")
    fig.add_hline(y=-2.0, line_dash="dash", line_color=DROUGHT_COLORS["Severe"],
                  annotation_text="Severe threshold")
    fig.update_layout(
        title=f"Standardized Precipitation Index (SPI-{scale})",
        xaxis_title="Date",
        yaxis_title=f"SPI-{scale}",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=350,
        margin=dict(l=20, r=20, t=50, b=20),
    )
    return fig


# ─── Drought Distribution Pie ─────────────────────────────────────────────────

def plot_drought_distribution(df: pd.DataFrame) -> go.Figure:
    """Pie chart of drought class distribution."""
    if "drought_class" not in df.columns:
        return go.Figure()

    counts = df["drought_class"].value_counts().reindex(CLASS_ORDER, fill_value=0)
    fig = go.Figure(go.Pie(
        labels=counts.index,
        values=counts.values,
        marker_colors=[DROUGHT_COLORS[c] for c in counts.index],
        hole=0.4,
        textinfo="label+percent",
    ))
    fig.update_layout(
        title="Drought Severity Distribution",
        paper_bgcolor="rgba(0,0,0,0)",
        height=320,
        margin=dict(l=20, r=20, t=50, b=20),
        showlegend=False,
    )
    return fig


# ─── VCI / TCI / VHI Line Plot ────────────────────────────────────────────────

def plot_vhi(df: pd.DataFrame) -> go.Figure:
    """Line chart of VCI, TCI, and VHI over time."""
    fig = go.Figure()
    for col, color, name in [
        ("VCI", "#27ae60", "Vegetation Condition Index"),
        ("TCI", "#e74c3c", "Temperature Condition Index"),
        ("VHI", "#3498db", "Vegetation Health Index"),
    ]:
        if col in df.columns:
            fig.add_trace(go.Scatter(
                x=df["date"].astype(str), y=df[col],
                mode="lines", name=name,
                line=dict(color=color, width=2),
            ))

    fig.add_hrect(y0=0, y1=10,   fillcolor="#e74c3c", opacity=0.1, line_width=0, annotation_text="Extreme")
    fig.add_hrect(y0=10, y1=20,  fillcolor="#e67e22", opacity=0.1, line_width=0, annotation_text="Severe")
    fig.add_hrect(y0=20, y1=30,  fillcolor="#f1c40f", opacity=0.1, line_width=0, annotation_text="Moderate")
    fig.add_hrect(y0=30, y1=40,  fillcolor="#2ecc71", opacity=0.1, line_width=0, annotation_text="Mild")

    fig.update_layout(
        title="Vegetation & Temperature Health Indices",
        xaxis_title="Date",
        yaxis_title="Index (0–100)",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=380,
        margin=dict(l=20, r=20, t=50, b=20),
    )
    return fig


# ─── Confusion Matrix ─────────────────────────────────────────────────────────

def plot_confusion_matrix(cm: np.ndarray) -> go.Figure:
    """Heatmap of confusion matrix."""
    fig = px.imshow(
        cm,
        labels=dict(x="Predicted", y="Actual", color="Count"),
        x=CLASS_ORDER, y=CLASS_ORDER,
        color_continuous_scale="Blues",
        text_auto=True,
    )
    fig.update_layout(
        title="Confusion Matrix",
        paper_bgcolor="rgba(0,0,0,0)",
        height=380,
        margin=dict(l=20, r=20, t=50, b=20),
    )
    return fig


# ─── Training History ─────────────────────────────────────────────────────────

def plot_training_history(history_dict: dict) -> go.Figure:
    """Plot training/validation loss and accuracy."""
    fig = make_subplots(rows=1, cols=2,
                        subplot_titles=("Loss", "Accuracy"))

    epochs = list(range(1, len(history_dict["loss"]) + 1))

    fig.add_trace(go.Scatter(x=epochs, y=history_dict["loss"],
                             name="Train Loss", line=dict(color="#e74c3c")), row=1, col=1)
    if "val_loss" in history_dict:
        fig.add_trace(go.Scatter(x=epochs, y=history_dict["val_loss"],
                                 name="Val Loss", line=dict(color="#e74c3c", dash="dash")), row=1, col=1)

    fig.add_trace(go.Scatter(x=epochs, y=history_dict["accuracy"],
                             name="Train Acc", line=dict(color="#2ecc71")), row=1, col=2)
    if "val_accuracy" in history_dict:
        fig.add_trace(go.Scatter(x=epochs, y=history_dict["val_accuracy"],
                                 name="Val Acc", line=dict(color="#2ecc71", dash="dash")), row=1, col=2)

    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=350,
        margin=dict(l=20, r=20, t=50, b=20),
    )
    return fig
