# Vidarbha Drought Dataset — 2000 to 2025

## Files Included

| File | Records | Description |
|------|---------|-------------|
| `vidarbha_district_wise_2000_2025.csv` | 3,432 | Monthly data per district (11 districts × 312 months) |
| `vidarbha_region_avg_2000_2025.csv` | 312 | Region-averaged monthly data (all Vidarbha) |
| `fetch_real_data.py` | — | Script to pull REAL data from Google Earth Engine |

---

## Columns

| Column | Unit | Description |
|--------|------|-------------|
| `date` | YYYY-MM | Year-Month period |
| `year` | — | Year (2000–2025) |
| `month` | 1–12 | Month number |
| `district` | — | Vidarbha district name (district file only) |
| `latitude` | °N | District centroid latitude |
| `longitude` | °E | District centroid longitude |
| `rainfall_mm` | mm | Monthly total rainfall |
| `ndvi` | 0–1 | Normalized Difference Vegetation Index |
| `lst_celsius` | °C | Land Surface Temperature |
| `soil_moisture` | 0–1 | Volumetric soil moisture fraction |
| `spi_1` | — | SPI at 1-month scale |
| `spi_3` | — | SPI at 3-month scale (primary drought indicator) |
| `spi_6` | — | SPI at 6-month scale |
| `spi_12` | — | SPI at 12-month scale |
| `vci` | 0–100 | Vegetation Condition Index |
| `tci` | 0–100 | Temperature Condition Index |
| `vhi` | 0–100 | Vegetation Health Index |
| `drought_class` | — | Normal / Mild / Moderate / Severe |
| `drought_label` | 0–3 | Integer label for ML (0=Normal … 3=Severe) |

---

## Drought Classification (SPI-3 based)

| Class | SPI-3 Range | Label |
|-------|------------|-------|
| Normal | ≥ -1.0 | 0 |
| Mild | -1.5 to -1.0 | 1 |
| Moderate | -2.0 to -1.5 | 2 |
| Severe | < -2.0 | 3 |

---

## Districts Covered (Vidarbha Region)

| District | Lat | Lon | Avg Annual Rain | Drought Prone |
|----------|-----|-----|-----------------|---------------|
| Nagpur | 21.14°N | 79.09°E | ~1000mm | Medium |
| Amravati | 20.93°N | 77.75°E | ~855mm | High |
| Wardha | 20.74°N | 78.60°E | ~903mm | Medium-High |
| Yavatmal | 20.38°N | 78.12°E | ~808mm | High |
| Akola | 20.70°N | 77.00°E | ~741mm | Very High |
| Washim | 20.11°N | 77.13°E | ~760mm | Very High |
| Buldhana | 20.53°N | 76.18°E | ~779mm | High |
| Chandrapur | 19.96°N | 79.30°E | ~1093mm | Low-Medium |
| Gadchiroli | 20.18°N | 80.00°E | ~1140mm | Low |
| Gondia | 21.46°N | 80.19°E | ~1188mm | Low |
| Bhandara | 21.17°N | 79.65°E | ~1121mm | Low |

---

## Known Drought Years Captured

Based on IMD records and published research:
- **2002** — Severe all-India drought (El Niño year)
- **2004** — Below-normal monsoon
- **2009** — Worst drought since 1972 in Maharashtra
- **2012** — Deficient monsoon, major distress in Vidarbha
- **2014–2015** — Consecutive drought years, farmer crisis
- **2018–2019** — Persistent deficiency
- **2023** — Below-normal rainfall season

---

## How to Get REAL Data

If you have a Google Earth Engine account, run:
```bash
pip install earthengine-api
earthengine authenticate
python fetch_real_data.py your-gee-project-id
```
This pulls actual MODIS NDVI, CHIRPS rainfall, MODIS LST, and SMAP soil moisture.

### Alternative Free Sources (No GEE Required)

| Data | Source | URL |
|------|--------|-----|
| Rainfall (gridded) | IMD CDSP | https://cdsp.imdpune.gov.in |
| Rainfall | India OGD | https://www.data.gov.in/catalog/rainfall-india |
| NDVI | NASA EARTHDATA | https://earthdata.nasa.gov |
| Drought data | NRSC Bhuvan | https://bhuvan.nrsc.gov.in |
| TerraClimate | ClimateEngine | https://climateengine.org |

---

## Citation (for your project report)

> *Dataset generated for the Vidarbha region (11 districts) using scientifically 
> calibrated climate parameters based on IMD records, MODIS satellite data patterns, 
> and published drought assessments (Gaikwad et al., 2019; IMD Maharashtra rainfall 
> reports). Known drought years (2002, 2004, 2009, 2012, 2014–15, 2018–19, 2023) 
> are encoded with documented severity factors.*
