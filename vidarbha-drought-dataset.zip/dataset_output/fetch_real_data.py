"""
fetch_real_data.py — Fetch REAL Vidarbha satellite data from free sources

Sources used:
  1. CHIRPS  — Rainfall (via GEE)
  2. MODIS MOD13A2 — NDVI (via GEE)
  3. MODIS MOD11A2 — LST (via GEE)
  4. SMAP L3  — Soil Moisture (via GEE, from 2015 onward)
  5. IMD      — Gridded rainfall (alternative, via cdsp.imdpune.gov.in)

Requirements:
  pip install earthengine-api geemap pandas numpy

Usage:
  earthengine authenticate   ← first time only
  python fetch_real_data.py
"""

import ee
import numpy as np
import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta

# ── Vidarbha bounding boxes per district ──────────────────────────────────────
DISTRICTS = {
    "Nagpur":     ee.Geometry.Rectangle([78.6, 20.7, 79.7, 21.8]),
    "Amravati":   ee.Geometry.Rectangle([77.1, 20.4, 78.4, 21.5]),
    "Wardha":     ee.Geometry.Rectangle([78.1, 20.3, 79.2, 21.1]),
    "Yavatmal":   ee.Geometry.Rectangle([77.6, 19.8, 79.0, 20.8]),
    "Akola":      ee.Geometry.Rectangle([76.7, 20.3, 77.6, 21.1]),
    "Washim":     ee.Geometry.Rectangle([76.9, 19.9, 77.7, 20.6]),
    "Buldhana":   ee.Geometry.Rectangle([75.9, 20.0, 77.0, 21.0]),
    "Chandrapur": ee.Geometry.Rectangle([78.8, 19.5, 80.1, 20.6]),
    "Gadchiroli": ee.Geometry.Rectangle([79.5, 19.5, 80.5, 20.8]),
    "Gondia":     ee.Geometry.Rectangle([79.8, 21.0, 80.6, 21.8]),
    "Bhandara":   ee.Geometry.Rectangle([79.4, 20.8, 80.2, 21.5]),
}

START_DATE = "2000-02-01"   # MODIS available from Feb 2000
END_DATE   = "2025-12-31"


def init_gee(project_id: str = "your-project-id"):
    ee.Initialize(project=project_id)
    print("✅ GEE initialized")


def get_monthly_mean(collection_id: str, band: str,
                     geometry, start: str, end: str,
                     scale_factor: float = 1.0,
                     offset: float = 0.0) -> float | None:
    try:
        col = (ee.ImageCollection(collection_id)
               .filterDate(start, end)
               .filterBounds(geometry)
               .select(band))
        if col.size().getInfo() == 0:
            return None
        val = (col.mean()
                  .multiply(scale_factor)
                  .add(offset)
                  .reduceRegion(ee.Reducer.mean(), geometry, scale=1000)
                  .get(band)
                  .getInfo())
        return round(float(val), 4) if val is not None else None
    except Exception as e:
        print(f"    ⚠ {e}")
        return None


def fetch_all(project_id: str = "your-project-id"):
    init_gee(project_id)

    records = []
    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt   = datetime.strptime(END_DATE,   "%Y-%m-%d")
    current  = start_dt

    total_months = (end_dt.year - start_dt.year) * 12 + (end_dt.month - start_dt.month) + 1
    done = 0

    while current <= end_dt:
        y, m = current.year, current.month
        s = f"{y}-{m:02d}-01"
        e = (current + relativedelta(months=1)).strftime("%Y-%m-%d")

        for district, geom in DISTRICTS.items():
            print(f"  [{done+1}/{total_months * len(DISTRICTS)}] {y}-{m:02d} {district}", end="\r")

            ndvi = get_monthly_mean(
                "MODIS/061/MOD13A2", "NDVI", geom, s, e,
                scale_factor=0.0001)

            rainfall = get_monthly_mean(
                "UCSB-CHG/CHIRPS/DAILY", "precipitation", geom, s, e)
            # CHIRPS is daily mm, sum over month
            try:
                col = (ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY")
                       .filterDate(s, e).filterBounds(geom).select("precipitation"))
                rain_val = (col.sum()
                              .reduceRegion(ee.Reducer.mean(), geom, scale=5000)
                              .get("precipitation").getInfo())
                rainfall = round(float(rain_val), 2) if rain_val is not None else None
            except:
                rainfall = None

            # LST: scale 0.02, convert K to °C
            lst = get_monthly_mean(
                "MODIS/061/MOD11A2", "LST_Day_1km", geom, s, e,
                scale_factor=0.02, offset=-273.15)

            # Soil moisture (SMAP only from April 2015)
            sm = None
            if current >= datetime(2015, 4, 1):
                sm = get_monthly_mean(
                    "NASA/SMAP/SPL3SMP_E/006",
                    "soil_moisture_am", geom, s, e)

            records.append({
                "date":          f"{y}-{m:02d}",
                "year":          y,
                "month":         m,
                "district":      district,
                "rainfall_mm":   rainfall,
                "ndvi":          ndvi,
                "lst_celsius":   lst,
                "soil_moisture": sm,
            })

        current += relativedelta(months=1)
        done += 1

        # Save checkpoint every 12 months
        if done % 12 == 0:
            pd.DataFrame(records).to_csv("vidarbha_real_data_checkpoint.csv", index=False)
            print(f"\n  💾 Checkpoint saved ({done}/{total_months} months)")

    df = pd.DataFrame(records)
    df.to_csv("vidarbha_real_satellite_2000_2025.csv", index=False)
    print(f"\n✅ Done! {len(df)} records saved.")
    return df


if __name__ == "__main__":
    import sys
    project = sys.argv[1] if len(sys.argv) > 1 else "your-gee-project-id"
    fetch_all(project)
